/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [LegacyExOrdID]
      ,[LegacyDBID]
      ,[LegacySPID]
      ,[OrgID]
      ,[FvProdPrefix]
      ,[ExecutionOrder]
      ,[Active]
      ,[CreatedDate]
      ,[ModifiedDate]
  FROM [990000035_SingerKatz_R1].[PT1].[LegacySPExecutionOrder]

  insert into [990000035_SingerKatz_R1].[PT1].[LegacySPExecutionOrder]
  ([LegacyDBID]
      ,[LegacySPID]
      ,[OrgID]
      ,[FvProdPrefix]
      ,[ExecutionOrder]
      ,[Active]
      ,[CreatedDate]
      ,[ModifiedDate])
	  values
	  (12,
	  20801	  
	  ,990000035
	  ,'_T1SingerKatz_'
	  ,920
	  ,1
	  ,getdate()
	  ,NULL)

  insert into [990000035_SingerKatz_R1].[PT1].[LegacySPExecutionOrder]
  ([LegacyDBID]
      ,[LegacySPID]
      ,[OrgID]
      ,[FvProdPrefix]
      ,[ExecutionOrder]
      ,[Active]
      ,[CreatedDate]
      ,[ModifiedDate])
	  values
	  (12
	  ,20800	  
	  ,990000035
	  ,'_T1SingerKatz_'
	  ,910
	  ,1
	  ,getdate()
	  ,NULL)

	  update [990000035_SingerKatz_R1].[PT1].[LegacySPExecutionOrder]



	  200		usp_insert_reference_Usernames				
400		usp_insert_reference_ClientCaseMap			
500		usp_insert_staging_Contacts					
600		usp_insert_staging_Projects					
700		usp_insert_staging_CalendarEvents			
700		usp_insert_staging_Deadlines				
700		usp_insert_staging_Notes					
700		usp_insert_staging_ProjectContacts			
700		usp_insert_staging_ProjectPermissions		
800		usp_insert_reference_Documents				
900		usp_insert_staging_Documents